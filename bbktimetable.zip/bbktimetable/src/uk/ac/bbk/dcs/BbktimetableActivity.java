package uk.ac.bbk.dcs;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.auth.AuthenticationException;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.scheme.SocketFactory;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class BbktimetableActivity extends Activity implements OnClickListener {
	public static final String url = "https://puck.mda.bbk.ac.uk/bsis_student/pp_stu";
	private static EditText uname;
	private static EditText pword;
	private Button submit;
	private HttpClient c;

	@Override
	public void onResume() {
		super.onResume();
		/*
		 * Toast.makeText(BbktimetableActivity.this, "  onResume called",
		 * Toast.LENGTH_LONG).show();
		 */}

	@Override
	public void onPause() {
		super.onPause();
		/*
		 * Toast.makeText(BbktimetableActivity.this, "  onPause called",
		 * Toast.LENGTH_LONG).show();
		 */}

	@Override
	public void onDestroy() {
		super.onDestroy();
		/*
		 * Toast.makeText(BbktimetableActivity.this, " on destroy called",
		 * Toast.LENGTH_LONG).show();
		 */System.gc();
		submit.setBackgroundDrawable(null);
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		uname = (EditText) findViewById(R.id.username);
		pword = (EditText) findViewById(R.id.password);
		submit = (Button) findViewById(R.id.buttonsubmit);

		try {
			c = getNewHttpClient();
		} catch (Exception e) {
			throw new RuntimeException("Unable to initialise HttpClient", e);
		}
		submit.setOnClickListener(BbktimetableActivity.this);
	}

	public void onClick(View v) {
		String page = null;
		page = getPage(url);
		if (page != null) {
			String id = getStudentId(page);
			if (id != null) {
				String url2 = url + "tt?pstuc=" + id;
				System.out.println("***** Fetching timetable URL " + url2
						+ "*****");
				page = null;
				page = getPage(url2);
				if (page != null) {

					// System.out.println(page);

					if (v == submit) {
						Intent timetableIntent = new Intent(v.getContext(),
								MyTimetableActivity.class);
						startActivity(timetableIntent);
						callNull();
						Document doc = Jsoup.parse(page);
						// (?<=www).*(?=.com)

						// parse html for timetable and show timetable
					}
				}
			} else {
				System.out.println("Failed to login as Student");
			}
		}
	}

	public void callNull() {
		this.finish();
	}

	public String getPage(String url) {
		String page = null;
		HttpUriRequest request = null;

		if (getCredential() != null) {
			request = new HttpGet(url);

			try {
				request.addHeader(new BasicScheme().authenticate(
						getCredential(), request));
			} catch (AuthenticationException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		} else {
			System.out.println("Credentials blank");
		}

		try {
			HttpResponse response = c.execute(request);
			page = EntityUtils.toString(response.getEntity());
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		return page;
	}

	public String getStudentId(String page) {
		String studentId = null;

		Pattern pattern = Pattern.compile("pstuc=(\\d+)\\'");
		Matcher matcher = pattern.matcher(page);
		if (matcher.find()) {
			studentId = matcher.group(1);
			System.out.println("Student ID is :" + studentId);
		} else {
			System.out.println("No valid Student ID found");
			Toast.makeText(this, "Login failed, please try again",
					Toast.LENGTH_LONG).show();
		}
		return studentId;
	}

	public HttpClient getNewHttpClient() throws KeyStoreException,
			KeyManagementException, NoSuchAlgorithmException,
			UnrecoverableKeyException, CertificateException, IOException {

		KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
		trustStore.load(null, null);

		SSLSocketFactory sf = new InsecureSslSocketFactory(trustStore);
		sf.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);

		HttpParams params = new BasicHttpParams();
		HttpProtocolParams.setVersion(params, HttpVersion.HTTP_1_1);
		HttpProtocolParams.setContentCharset(params, HTTP.UTF_8);

		SchemeRegistry registry = new SchemeRegistry();
		registry.register(new Scheme("http", PlainSocketFactory
				.getSocketFactory(), 80));
		registry.register(new Scheme("https", (SocketFactory) sf, 443));

		ClientConnectionManager ccm = new ThreadSafeClientConnManager(params,
				registry);

		return new DefaultHttpClient(ccm, params);
	}

	public static UsernamePasswordCredentials getCredential() {
		String username = "jjoshi02";
		String password = "";

		// String username = uname.getText().toString();
		// String password = pword.getText().toString();

		UsernamePasswordCredentials creds = null;

		System.out.println("User ID :" + username);
		System.out.println("Password is :" + password);

		return creds = new UsernamePasswordCredentials(username, password);
	}
}

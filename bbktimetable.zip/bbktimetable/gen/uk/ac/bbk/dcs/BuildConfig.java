/** Automatically generated file. DO NOT MODIFY */
package uk.ac.bbk.dcs;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}